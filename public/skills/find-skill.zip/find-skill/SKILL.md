---
name: find-skill
description: Help Chinese-speaking users discover, choose, understand, and use Codex skills, plugins, connectors, apps, MCP tools, and related capabilities. Use when the user asks which Codex plugin or skill to use, says they cannot understand English skill/plugin descriptions, asks for Chinese usage examples, asks how to trigger an available capability, mentions "find skill", "找 skill", "插件怎么用", "用哪个插件", or wants Codex to select and apply the right capability for a task.
---

# Find Skill

## Goal

Help the user use Codex capabilities without needing to read English plugin or skill documentation. Prefer practical Chinese guidance and runnable next steps over literal translation.

## Workflow

1. Identify the user's actual task, not just the plugin name. If the request is unclear, infer a likely intent and state the assumption in Chinese.
2. Check the capabilities already visible in the current context:
   - Skills listed in the system context.
   - Plugin-contributed skills, which are named like `plugin-name:skill-name`.
   - Available app, MCP, and tool-search capabilities if the user asks about plugins, connectors, browser control, GitHub, Canva, documents, spreadsheets, automations, or thread management.
3. If the user mentions a tool or plugin that is not directly visible, use `tool_search` when available to search for matching callable tools. If the user explicitly asks to install a specific missing plugin or connector, follow the normal plugin install flow.
4. Pick the smallest useful capability set. Prefer one skill when one covers the task. Combine skills only when the user task genuinely spans multiple domains.
5. Before performing work with a selected skill, read that skill's `SKILL.md` as required by the normal skill rules. If the user only wants an explanation, reading metadata may be enough unless the details matter.
6. Explain the result in Chinese, using the user's likely vocabulary rather than English labels alone.
7. If the user wants the task done, do it after choosing the capability. Do not stop at a recommendation unless the user only asked for advice.

## Chinese Explanation Format

When recommending a skill or plugin, include:

- `推荐`: the skill/plugin/app name and a short Chinese name.
- `适合做`: 2-4 concrete task types.
- `不适合`: important limits or when to avoid it.
- `怎么说`: 2-5 Chinese prompt examples the user can type directly.
- `我可以直接帮你做`: the next action Codex can take now.

Keep explanations short when the user is trying to get work done. Use more detail only when the user asks to learn.

## Prompt Examples To Offer

Use examples like these, adapted to the available skills:

```text
用 $github:gh-fix-ci 帮我看这个 PR 为什么 CI 失败，并修复。
用 $documents:documents 把这个 docx 改成正式合同格式，并保留修订痕迹。
用 $spreadsheets:Spreadsheets 分析这个 Excel，做透视表和图表。
用 $browser:control-in-app-browser 打开本地页面，检查按钮是否能点击。
用 $wechat-miniprogram 帮我改这个微信小程序页面。
用 $imagegen 生成一张小红书封面图。
```

## Plugin Guidance

A plugin is usually not called directly. It exposes one or more skills, apps, MCP tools, or browser/computer tools. When explaining a plugin, map it to the thing the user can actually ask Codex to use.

Examples:

- GitHub plugin -> GitHub PR/issue skills and GitHub app tools.
- Browser plugin -> in-app browser control skill/tools.
- Canva plugin -> Canva presentation, resize, or translation skills.
- HyperFrames plugin -> video composition and rendering skills.

## Handling English Documentation

If the selected skill or plugin documentation is in English:

1. Read only the relevant instructions needed for the user's task.
2. Summarize in Chinese instead of translating the entire document.
3. Preserve exact English names for commands, skill names, tool names, file paths, and API identifiers.
4. Warn the user in Chinese if a step has side effects, requires login, creates files, installs tools, publishes content, or uses an external service.

## If No Match Exists

Say clearly in Chinese that no exact skill/plugin is currently available. Then offer the best fallback:

- Use general Codex coding or file editing.
- Search for installable plugins only when the user explicitly asked for a specific plugin.
- Create a new skill if the user wants repeated help for the same workflow.
