#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""课程视频批量转录：mp4 → Obsidian 知识库/转录/*.md
用法：改 COURSES 列表 → export HF_ENDPOINT=https://hf-mirror.com → python 本脚本（可 nohup 后台）
特性：断点续跑（输出存在即跳过）、失败计数、逐集日志（~/transcribe_log.txt）
2026-08-23 实测：49 集 2.1G 视频，small 模型 int8 cpu_threads=4，M1 8GB，零失败。
"""
import os, sys, glob, time

VAULT = "~/Desktop/个人知识库/01 输入与剪存"
COURSES = [
    {
        "name": "示例课程_知识库名",
        "src": "/path/to/video/dir",
        "glob": "*.mp4",
    },
]
MODEL_SIZE = os.environ.get("WHISPER_MODEL", "small")
LOG = os.path.expanduser("~/transcribe_log.txt")

def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")

def transcribe(model, video, out_md):
    seg_texts = []
    try:
        segments, info = model.transcribe(video, language="zh", beam_size=3,
                                          vad_filter=True, vad_parameters={"min_silence_duration_ms": 500})
        for seg in segments:
            seg_texts.append(seg.text.strip())
    except Exception as e:
        log(f"  ❌ 转录失败 {os.path.basename(video)}: {e}")
        return False
    text = "\n".join(seg_texts)
    if not text.strip():
        log(f"  ⚠️ 空转录 {os.path.basename(video)}")
        return False
    title = os.path.splitext(os.path.basename(video))[0]
    md = f"# {title}\n\n> 转录自课程视频（whisper {MODEL_SIZE}，自动生成，可能有错别字，仅作检索与蒸馏参考）\n\n{text}\n"
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    with open(out_md, "w") as f:
        f.write(md)
    return True

def main():
    log(f"=== 转录启动：模型={MODEL_SIZE} ===")
    os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")  # 国内镜像（HF 直连被墙）
    from faster_whisper import WhisperModel
    model = WhisperModel(MODEL_SIZE, device="cpu", compute_type="int8", cpu_threads=4)  # 8GB 内存限 4 线程防 OOM
    total_ok = total_fail = 0
    for course in COURSES:
        out_dir = os.path.join(VAULT, course["name"], "转录")
        videos = sorted(glob.glob(os.path.join(course["src"], course["glob"])))
        log(f"课程「{course['name']}」共 {len(videos)} 集")
        for v in videos:
            base = os.path.splitext(os.path.basename(v))[0]
            out_md = os.path.join(out_dir, base + ".md")
            if os.path.exists(out_md) and os.path.getsize(out_md) > 500:
                log(f"  ⏭️ 已存在跳过：{base}")
                continue
            log(f"  ▶️ 转录中：{base}")
            t0 = time.time()
            ok = transcribe(model, v, out_md)
            dt = time.time() - t0
            if ok:
                total_ok += 1
                log(f"  ✅ 完成 {base}（{dt:.0f}s）")
            else:
                total_fail += 1
                log(f"  ❌ 失败 {base}")
    log(f"=== 全部结束：成功 {total_ok}，失败 {total_fail} ===")

if __name__ == "__main__":
    main()
