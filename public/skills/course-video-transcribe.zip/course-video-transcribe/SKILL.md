---
name: course-video-transcribe
description: "本地课程视频批量转录→Obsidian知识库。触发：课程视频要蒸馏/转录/建语料库/做培训素材。"
version: 1.0.0
metadata:
  hermes:
    tags: [video, whisper, transcribe, obsidian, course, training]
---

# 课程视频转录蒸馏（Course Video → Obsidian 知识库）

把本地课程视频（mp4 批量）转录成文本，蒸馏进 Obsidian 知识库，作为培训语料库。2026-08-23 实测：姜老师32集+携程17集（2.1G）→ 49 个转录文档，零失败。

## 触发场景

用户说「课程视频帮我蒸馏/转录/建知识库」「这两个课程作为语料库」「培训要用」等。

## 核心流程

### ① 建知识库结构（先做，立即有价值）
在 vault `01 输入与剪存/` 下建 `<课程名>_知识库/`：
- `00 索引.md`：课程定位、来源路径、适用场景（用户业务挂钩）、大纲表（集数→模块）、学习路径、状态
- `01 方法论蒸馏.md`：基于**视频文件名大纲**提炼模块化方法论地图；标注「🎯」可复用要点；附「培训转化建议」（用户是讲师）；⚠️ 注明是标题级框架
- 登记到 `01 输入与剪存/00 全盘资料读取索引.md`（课程知识库登记表）

### ② 环境准备（一次性）
```bash
python3 -m venv ~/.whisper-venv
~/.whisper-venv/bin/pip install -q -U pip faster-whisper
export HF_ENDPOINT=https://hf-mirror.com   # 必须！HF 直连被墙
~/.whisper-venv/bin/python -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-whisper-small')"  # 预下载模型(~460MB)
```

### ③ 测速选模型（每批第一次）
单集试转：`WhisperModel('small', device='cpu', compute_type='int8', cpu_threads=4)`。M1 8GB 实测：30min 视频 ≈ 6.4min（4.6x 实时）；中文用 small（base 错字多）。

### ④ 批量转录（后台跑）
用 `scripts/transcribe_courses.py`（改 COURSES 列表指向课程目录+输出目录）：
```bash
export HF_ENDPOINT=https://hf-mirror.com
nohup <你的whisper环境>/bin/python scripts/transcribe_courses.py >> ~/transcribe_log.txt 2>&1 &
```
脚本特性：断点续跑（输出 md 存在即跳过）、失败重试计数、逐集日志。

### ⑤ 收尾
- 抽查 2 集转录质量（读开头，同音错字属正常）
- 更新两个 00 索引状态 🟡→🟢（勾选「视频转文字」）
- 更新全盘索引登记
- 提醒用户：视频原件上云后删本地（知识库框架+转录保留）

## Pitfalls（M1 8GB 实测）

1. **HuggingFace 被墙**：不设 `HF_ENDPOINT=https://hf-mirror.com` 必超时。脚本内也要 `os.environ.setdefault`。
2. **长视频 OOM 被杀**：8GB 内存转 >20min 视频会在写完 md 后、下集开始前被 jetsam 杀掉（日志停在「转录中」，无「✅ 完成」）。对策：`cpu_threads=4` 降内存；`nohup` 防挂断；脚本断点续跑；**转录前提醒用户关内存大户**；查活：`pgrep -f transcribe_courses`，数产出：`find ... -name "*.md" | wc -l`。
3. **日志双写**：脚本内 log() 已 append 文件，外层再 `>>` 重定向会重复行——无害但别以为出 bug。
4. **whisper 同音错字**（毒品=东西、律力房等）：正常，转录文档标注「自动生成，可能有错别字，仅作检索与蒸馏参考」。
5. **后台进程句柄会丢**：nohup 后 process poll 可能 not_found，用 `pgrep -f transcribe_courses` + 数 md 文件确认实际状态，别误判死亡。
6. **python 版本**：系统 3.9 可用；venv 内装 faster-whisper 即可，勿动系统 python。

## 验证

- 完成：日志出现「=== 全部结束：成功 N，失败 0 ===」且 md 计数=集数
- 质量：抽查读 md 前 20 行，内容连贯即可
- 知识库：00 索引状态 🟢、全盘索引已登记
