# CandyPPT 设计变量速查表

## 配色系统

### 主色（马卡龙五色）

| 变量名 | 色值 | 用途 | 预览 |
|---|---|---|---|
| `--pink` | `#ff6b8a` | 主强调色、数字、标题强调 | 🔴 珊瑚粉 |
| `--yellow` | `#ffc93c` | 辅助强调、标签背景 | 🟡 阳光黄 |
| `--blue` | `#5eb8ff` | 信息类、链接、第二强调 | 🔵 天空蓝 |
| `--green` | `#5fd0a0` | 成功、正面、第三强调 | 🟢 薄荷绿 |
| `--purple` | `#b088f9` | AI/科技类、第四强调 | 🟣 薰衣草紫 |
| `--orange` | `#ff9a5c` | 警告、注意、第五强调 | 🟠 活力橙 |

### 浅色变体（背景用）

| 变量名 | 色值 | 用途 |
|---|---|---|
| `--pink-bg` | `#fff0f3` | 粉色卡片背景、标签 |
| `--yellow-bg` | `#fffbeb` | 黄色卡片背景、标签 |
| `--blue-bg` | `#eff8ff` | 蓝色卡片背景、标签 |
| `--green-bg` | `#f0fdf6` | 绿色卡片背景、标签 |
| `--purple-bg` | `#f7f2ff` | 紫色卡片背景、标签 |

### 文字色

| 变量名 | 色值 | 用途 |
|---|---|---|
| `--text` | `#2d2d3a` | 主标题、正文 |
| `--text2` | `#6b6b80` | 次要文字、说明 |
| `--text3` | `#a0a0b5` | 辅助文字、页码、标签 |

### 背景色

| 变量名 | 色值 | 用途 |
|---|---|---|
| `--bg` | `#fef9f6` | 页面默认背景（暖白） |
| `--card` | `#ffffff` | 卡片背景 |
| `--white` | `#ffffff` | 纯白 |

## 圆角系统

| 元素 | 圆角值 |
|---|---|
| 卡片 `.card` | 18px |
| 数据卡片 `.data-card` | 20px |
| 金句卡 `.hammer-card` | 32px |
| 标签/按钮 `.eyebrow` `.cover-tag` | 20px（胶囊形） |
| 提示条 `.tip` | 14px |
| 表格容器 `.tbl-wrap` | 20px |
| 导航 `.nav` | 20px |

## 阴影系统

| 变量名 | 值 | 用途 |
|---|---|---|
| `--shadow` | `0 8px 30px rgba(255,107,138,.12)` | 大卡片悬浮（粉色调） |
| `--shadow-hover` | `0 14px 40px rgba(255,107,138,.2)` | 悬停状态（更深粉色调） |
| 卡片默认 | `0 4px 16px rgba(0,0,0,.05)` | 普通卡片 |
| 标签/页码 | `0 2px 10px rgba(0,0,0,.05)` | 小元素悬浮 |

## 字号系统

| 元素 | 字号 | 字重 |
|---|---|---|
| 封面标题 `.cover-title` | 72px | 900 |
| 章节标题 `.chapter-title` | 48px | 900 |
| 结尾标题 `.end-title` | 56px | 900 |
| 金句 `.hammer-text` | 42px | 900 |
| 内容页标题 `.ctitle` | 28px | 900 |
| 目录标题 `.agenda-title` | 38px | 900 |
| 数据大数字 `.data-score` | 56px | 900 |
| 卡片序号 `.card-num` | 36px | 900 |
| 卡片标题 `.card h3` | 14px | 800 |
| 正文 `.card p` | 12px | 400 |
| 副标题 `.cdesc` | 12px | 500 |
| 标签 `.eyebrow` | 11px | 700 |
| 页码 `.pagenum` | 11px | 600 |

## 动画时长

| 动画 | 时长 | 缓动函数 |
|---|---|---|
| 入场 `bounceIn` | 0.7s | `cubic-bezier(.34,1.56,.64,1)`（弹性） |
| 悬停 `card:hover` | 0.35s | `cubic-bezier(.34,1.56,.64,1)` |
| 漂浮 `float` | 4-5s | ease-in-out（无限循环） |
| 脉冲 `pulse` | 3s | ease-in-out（无限循环） |
| 摇摆 `wiggle` | 2.5-3s | ease-in-out（无限循环） |
| 彩虹进度条 | 3s | ease（无限循环） |
| 进度条宽度变化 | 0.5s | `cubic-bezier(.34,1.56,.64,1)` |

## 页面内边距

| 元素 | 值 |
|---|---|
| 页面 `.slide` | 44px 60px（上下44，左右60） |
| 卡片 `.card` | 18px |
| 数据卡片 `.data-card` | 20px 16px |
| 金句卡 `.hammer-card` | 48px 56px |
| 提示条 `.tip` | 12px 18px |
| 标签 `.eyebrow` | 6px 16px |

## 渐变色组合（章节页/封面/结尾）

| 用途 | 渐变 |
|---|---|
| 封面（粉蓝紫） | `linear-gradient(135deg,#fff0f3 0%,#eff8ff 50%,#f7f2ff 100%)` |
| 章节页（紫蓝） | `linear-gradient(135deg,#667eea 0%,#764ba2 100%)` |
| 章节页（绿） | `linear-gradient(135deg,#11998e 0%,#38ef7d 100%)` |
| 结尾（粉黄） | `linear-gradient(135deg,#ff6b8a 0%,#ffa8b8 50%,#ffc93c 100%)` |
| 内容页（粉黄） | `linear-gradient(135deg,#fff0f3 0%,#fffbeb 100%)` |
| 内容页（蓝绿） | `linear-gradient(135deg,#eff8ff 0%,#f0fdf6 100%)` |
| 内容页（紫蓝） | `linear-gradient(135deg,#f7f2ff 0%,#eff8ff 100%)` |

## 装饰元素速查

| 元素 | CSS 类 | 用法 |
|---|---|---|
| 星星 emoji | `.deco.star` | `<div class="deco star" style="top:12%;left:8%;">⭐</div>` |
| 彩色圆点 | `.deco.dot` | `<div class="deco dot" style="bottom:20%;left:6%;background:var(--blue);"></div>` |
| 云朵 emoji | `.deco.cloud` | `<div class="deco cloud" style="top:15%;right:25%;">☁️</div>` |
| 气泡圆圈 | `.deco.bubble` | `<div class="deco bubble" style="top:60%;right:20%;color:var(--purple);"></div>` |

**装饰元素数量**：每页 2-4 个，分散在四角，不要遮挡内容。
