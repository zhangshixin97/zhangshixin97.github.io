---
name: candyppt
description: "CandyPPT · 糖果风幻灯片生成器。当用户需要制作活泼可爱、马卡龙配色、带动画效果的 HTML 幻灯片/PPT/培训课件/演示文稿时使用。适用于内部培训、团队分享、产品介绍、活动方案、课程课件等场景。核心特征：马卡龙多彩配色、大圆角卡片、柔和阴影、浮动装饰元素（星星/圆点/云朵/气泡）、弹跳入场动画、悬停交互动画、彩虹进度条。触发关键词：可爱风PPT、糖果风、马卡龙、活泼风格、动画PPT、HTML幻灯片、培训课件、可爱风格演示。"
---

# CandyPPT · 糖果风幻灯片

## 适用场景

- 企业内部培训课件（店长培训、员工培训、技能分享）
- 团队分享会、读书会、复盘会演示
- 产品介绍、活动方案、项目汇报
- 课程课件、教学演示
- 任何需要"活泼可爱 + 有动画 + 精美设计"的 HTML 幻灯片

**不适用**：正式商务汇报、投融资路演、法律/财务等严肃场景（建议使用极简商务风格）。

## 设计规范

### 1. 配色系统（马卡龙多彩）

```css
:root {
  --pink:#ff6b8a; --pink2:#ffa8b8; --pink-bg:#fff0f3;
  --yellow:#ffc93c; --yellow2:#ffe08a; --yellow-bg:#fffbeb;
  --blue:#5eb8ff; --blue2:#a8d8ff; --blue-bg:#eff8ff;
  --green:#5fd0a0; --green2:#a8e8c8; --green-bg:#f0fdf6;
  --purple:#b088f9; --purple2:#d0b8ff; --purple-bg:#f7f2ff;
  --orange:#ff9a5c; --orange2:#ffc09a;
  --text:#2d2d3a; --text2:#6b6b80; --text3:#a0a0b5;
  --white:#ffffff; --bg:#fef9f6; --card:#ffffff;
  --shadow:0 8px 30px rgba(255,107,138,.12);
  --shadow-hover:0 14px 40px rgba(255,107,138,.2);
}
```

**配色原则**：
- 每页使用 2-3 种马卡龙色作为主色调，不要全用上
- 章节页/封面/结尾用渐变色背景（2-3 色渐变）
- 内容页用浅色渐变背景或纯色背景
- 卡片顶部用 4-5px 彩色条区分模块
- 数字、强调文字用对应马卡龙色

### 2. 形状与圆角

- 卡片圆角：18-20px（大圆角，圆润可爱）
- 按钮/标签圆角：12-20px（胶囊形）
- 数据卡片圆角：20-24px
- 所有元素避免直角，统一圆润风格

### 3. 阴影

- 卡片默认阴影：`0 4px 16px rgba(0,0,0,.05)`（柔和，不突兀）
- 悬停阴影：`0 14px 40px rgba(255,107,138,.2)`（粉色调，有温度）
- 品牌标签/页码：`0 2px 10px rgba(0,0,0,.05)`（轻微悬浮）

### 4. 装饰元素

每页必须有 2-4 个装饰元素，增加活泼感：

| 元素 | 用法 | 动画 |
|---|---|---|
| ⭐ 星星 emoji | 页面角落，大小 24-40px | float 漂浮 3-5s |
| 彩色圆点 | 10-14px 圆形，马卡龙色 | float2 漂浮 3-4s |
| ☁️ 云朵 emoji | 背景装饰，透明度 0.5-0.7 | float 漂浮 4-6s |
| 气泡圆圈 | 空心圆，马卡龙色边框 | pulse 脉冲 3s |
| 🌈 彩虹 | 仅封面/结尾使用 | - |

**装饰元素位置原则**：分散在页面四角和边缘，不要遮挡内容，`pointer-events:none`。

### 5. 动画系统

#### 入场动画（必须）
```css
@keyframes bounceIn {
  from { opacity:0; transform:translateY(30px) scale(.95); }
  to { opacity:1; transform:translateY(0) scale(1); }
}
.slide.active .anim {
  animation: bounceIn .7s cubic-bezier(.34,1.56,.64,1) both;
}
/* 每个子元素延迟 0.07s，形成依次入场效果 */
.slide.active .anim:nth-child(1){animation-delay:.05s}
.slide.active .anim:nth-child(2){animation-delay:.12s}
```

#### 悬停动画（必须）
```css
.card:hover {
  transform: translateY(-6px) scale(1.02);
  box-shadow: var(--shadow-hover);
}
```

#### 背景装饰动画
```css
@keyframes float {
  0%,100% { transform:translateY(0) rotate(0deg); }
  50% { transform:translateY(-12px) rotate(3deg); }
}
@keyframes pulse {
  0%,100% { transform:scale(1); }
  50% { transform:scale(1.08); }
}
@keyframes wiggle {
  0%,100% { transform:rotate(-3deg); }
  50% { transform:rotate(3deg); }
}
```

#### 顶部进度条（彩虹流动）
```css
.progress {
  background: linear-gradient(90deg,var(--pink),var(--yellow),var(--blue),var(--green),var(--purple));
  background-size: 300% 100%;
  animation: rainbow 3s ease infinite;
}
```

### 6. 字体与排版

- 标题字重：900（超粗），字号 28-48px
- 正文字重：400-500，字号 12-14px
- 数字字重：900，使用 `font-variant-numeric:tabular-nums`
- 行高：标题 1.2-1.3，正文 1.6-1.75
- 标题必须带 emoji 图标（📱🏠🤖📊等），图标加 wiggle 动画

### 7. 页面类型模板

| 页面类型 | 特征 |
|---|---|
| 封面 | 渐变背景 + 大标题（多色）+ 浮动装饰 + 底部信息卡 |
| 金句/观点页 | 居中大白卡 + 大字号金句 + 彩色强调词 |
| 目录页 | 列表卡片 + 序号 + 时间标注 + 悬停右移 |
| 章节页 | 深色渐变背景 + 大数字（半透明）+ 章节标题 |
| 内容页 | 标题区 + 卡片网格（2/3/4列）+ 底部提示条 |
| 数据页 | 大数字卡片 + 表格 + 诊断提示 |
| 结尾页 | 渐变背景 + 大标题 + 行动号召 |

## 使用流程

### 第一步：确认需求

1. 确认培训/演示主题、目标受众、时长
2. 确认页数（建议 15-30 页，60 分钟培训约 25-30 页）
3. 确认是否有特定配色偏好（默认马卡龙多彩）

### 第二步：内容结构规划

按以下结构组织内容：
1. 封面（标题+副标题+讲师信息+时间）
2. 金句/核心观点页（1页，定调）
3. 目录页（1页）
4. 框架总览页（1页，讲清楚整体逻辑）
5. 各模块内容（章节页 + 内容页交替）
6. 行动清单页（1页，可落地的 TODO）
7. 结尾页（1页，总结+号召）

### 第三步：生成 HTML

使用 `templates/candyppt-template.html` 作为基础模板，替换内容。

**关键规则**：
- 每页内容不要太满，卡片内每个要点不超过 20 字
- 每页最多 4 列卡片，超过则分页
- 表格不超过 6 行，超过则精简或分页
- 底部提示条（tip）每页最多 1 个

### 第四步：溢出检测（必须）

生成后必须用浏览器打开，执行以下 JS 检测所有页面溢出：

```javascript
const slides = document.querySelectorAll('.slide');
slides.forEach((s, i) => {
  s.style.display = 'flex';
  if (s.scrollHeight > s.clientHeight + 5) {
    console.log(`Page ${i+1} overflow by ${s.scrollHeight - s.clientHeight}px`);
  }
  s.style.display = '';
});
```

**溢出修复优先级**：
1. 减少内容（精简文字、合并要点）
2. 减小字号/间距/padding
3. 调整布局（减少列数、分页）

### 第五步：视觉检查

- 逐页截图检查：装饰元素是否遮挡内容、颜色是否协调、动画是否流畅
- 检查封面、章节页、结尾页的渐变背景是否美观
- 检查卡片悬停效果是否正常

## 模板文件

- `templates/candyppt-template.html` — 完整 HTML 模板（含所有 CSS/JS/页面类型示例）
- `references/design-tokens.md` — 设计变量速查表

## 注意事项

1. **不要过度装饰**：每页装饰元素 2-4 个即可，太多会杂乱
2. **配色克制**：每页主色不超过 3 种，不要所有马卡龙色都用上
3. **动画不影响阅读**：入场动画 0.7s 内完成，不要太慢
4. **内容为王**：风格是为内容服务的，不要为了好看牺牲信息密度
5. **必须做溢出检测**：这是硬性要求，未检测不得交付
6. **中文引号**：HTML 中需要生成文字时，使用中文引号""
