---
name: xhs-collector
description: 小红书笔记/博主采集→Obsidian原文归档。触发：用户丢小红书链接或说「采集这篇/采集这个博主」。
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [小红书, 采集, Obsidian, 剪藏, 对标, 素材库]
    related_skills: [obsidian-input-sources, obsidian, chinese-tourism-ticket-reselling]
---

# 小红书采集（链接 → Obsidian 原文归档）

核心需求：小红书笔记原文存档（知识库铁律=原文零加工）+ 对标账号监控素材。2026-08-23 立项，替代付费插件「快小红一键采集」（该插件采集字段全但飞书出口只传 5 字段，弃用）。

## When to Use
- 用户丢小红书链接（长链或 xhslink 短链）并说「采集这篇」「存一下」「归档」
- 用户说「采集这个博主」「把这个博主的笔记都存下来」
- 用户发来快小红等工具导出的 CSV 要求转 Markdown 入库
- 对标账号监控：cron 定时抓对标博主新笔记 → 逐帧拆解素材（与抖音对标拆解流程联动）

## 触发场景
- 用户丢小红书链接（长链 `/explore/{id}`、`/discovery/item/{id}` 或 xhslink 短链）→「采集这篇」
- 用户说「采集这个博主」「把这个博主的笔记都存下来」
- 用户要求把第三方工具（快小红等）导出的 CSV 批量转 Markdown 入库

## 流程（v1 单篇采集）

1. **解析链接提取 note_id**：长链正则 `/(explore|discovery/item)/([0-9a-f]+)`；xhslink 短链需先跟随 302 得真实 URL（`curl -sL -o /dev/null -w '%{url_effective}'`）。
2. **抓取**：browser_exec 打开笔记页（**必须带登录态**——小红书未登录访问笔记详情页 404「当前笔记暂时无法浏览」error_code=300031，2026-08-23 实测）。登录态获取：让用户在浏览器里登录一次小红书，后续复用该 profile/session。
3. **结构化提取**（在页面 DOM 中取）：
   - 标题 `.title` / 作者 `.username` / 正文 `.note-text`、`#detail-desc .desc`（文本节点拼接，排除 `.tag`）
   - 标签 `.tag`（去 `#` 前缀）
   - 互动：`.like-wrapper .count` 点赞、`.collect-wrapper .count` 收藏、`.chat-wrapper .count` 评论（支持 `万`/`w`/`k` 单位换算）
   - 发布时间（支持「昨天 HH:mm」「X小时前」「X天前」「YYYY-MM-DD」「MM-DD」→ 规范化为 `YYYY/MM/DD HH:mm`，相对时间按采集时刻推算）
   - 图片 `.swiper-slide img`（过滤 avatar/placeholder/头像），视频 `video src` 或 performance 资源里 `.mp4/.m3u8`
   - 图文 vs 视频判定：有 videoUrl 且存在 `.xgplayer`/`video[mediatype="video"]` 且非 live 图 → 视频
4. **写 Markdown 存档**：`01 输入与剪存/13 小红书采集导入/01 笔记原文/YYYY/MM/YYYYMMDD_标题_笔记ID.md`
   - frontmatter：类型/作者/原文链接/赞藏评/发布时间/笔记类型/标签/采集时间/来源
   - 正文：原文全文 + `## 图片`（`图N=(url)` 列表）+ 可选「AI 拆解」区块（仅用户要求时加，默认零加工）
5. **博主采集**（v2）：主页滚动加载抓全部笔记链接 → 逐篇走 1-4；博主信息（昵称/小红书号/粉丝数/简介）存 `02 博主档案/`。

## 备用路径：第三方 CSV 转换
快小红等工具导出 CSV（列：标题,链接,作者,点赞数,图片链接）→ 用 `scripts/csv_to_md.py` 批量转 Markdown 入库（字段缺失标注「导出工具未提供」），文件放 `99 导出转换/`。

## 坑（实测 2026-08-23）
- **未登录 curl 直连笔记页必 404**——一切无登录态的抓取方案（curl/requests）不可行，浏览器自动化+登录态是唯一稳定路径
- 小红书无官方公开 API；内部接口 `/api/sns/web/v1/feed/detail` 需签名（x-s/x-t）+ cookie，易风控，不采用
- 小红书图片外链（xhscdn）有时效，长期存档需下载图片本地化（v2 事项）
- 小红书页面为 Vue 渲染，需等 `window.__INITIAL_STATE__` 或 DOM 加载完成再提取；失败先刷新重试
- 批量采博主笔记要控制频率，避免触发风控（间隔 ≥3s）
- 得到大脑读小红书链接存的是 AI 总结非原文——与本文档「原文存档」定位不同，两者并行不冲突

## 验证
- 采集后 `read_file` 复查：标题/正文/互动数是否与页面一致
- 文件写入 vault 即成功；如需进每日输入汇总，在 cron 900047532ed4 加「13 小红书采集导入」板块（聚合时间须晚于所有源推送）
