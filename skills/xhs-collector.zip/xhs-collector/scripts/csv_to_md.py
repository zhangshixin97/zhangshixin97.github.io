#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""快小红一键采集 等工具导出的 CSV → Obsidian Markdown 批量转换

用法:
    python3 csv_to_md.py <csv路径> [输出目录]

CSV 列约定（快小红导出格式）: 标题,链接,作者,点赞数,图片链接
输出: 每行一条 Markdown，带 frontmatter；输出目录默认
      ~/Desktop/个人知识库/01 输入与剪存/13 小红书采集导入/99 导出转换/
"""
import csv
import os
import re
import sys
from datetime import datetime

VAULT = os.path.expanduser("~/Desktop/个人知识库/01 输入与剪存/13 小红书采集导入/99 导出转换")


def sanitize_filename(title: str) -> str:
    title = re.sub(r'[\\/:*?"<>|\r\n\t]', '', title).strip()
    return title[:50] or "无标题"


def main():
    if len(sys.argv) < 2:
        print("用法: python3 csv_to_md.py <csv路径> [输出目录]")
        sys.exit(1)
    csv_path = sys.argv[1]
    out_dir = sys.argv[2] if len(sys.argv) > 2 else VAULT
    os.makedirs(out_dir, exist_ok=True)

    now = datetime.now().strftime("%Y%m%d_%H%M")
    count = 0
    with open(csv_path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            title = (row.get("标题") or "").strip()
            url = (row.get("链接") or "").strip()
            author = (row.get("作者") or "未知作者").strip()
            likes = (row.get("点赞数") or "0").strip()
            img = (row.get("图片链接") or "").strip()
            note_id = ""
            m = re.search(r"/(?:explore|discovery/item)/([0-9a-f]+)", url)
            if m:
                note_id = m.group(1)
            fname = f"{now}_{sanitize_filename(title)}_{note_id or 'no-id'}.md"
            frontmatter = (
                "---\n"
                "类型: 小红书笔记(工具导出转换)\n"
                "状态: 原始导入\n"
                f"标题: \"{title}\"\n"
                f"作者: \"{author}\"\n"
                f"点赞数: {likes}\n"
                f"原文链接: {url}\n"
                f"笔记ID: \"{note_id}\"\n"
                f"转换时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                "来源: 第三方工具CSV导出（字段缺失=导出工具未提供）\n"
                "---\n\n"
            )
            body = f"# {title}\n\n"
            body += f"> 作者：{author} ｜ 点赞：{likes} ｜ [原文链接]({url})\n\n"
            if img:
                body += f"## 图片\n\n![封面]({img})\n\n"
            body += "## 说明\n\n本条由第三方工具 CSV 转换入库，仅含导出字段（标题/链接/作者/点赞/封面）。"
            body += "正文全文请用 AI 助手采集（丢链接说「采集这篇」）。\n"
            with open(os.path.join(out_dir, fname), 'w', encoding='utf-8') as out:
                out.write(frontmatter + body)
            count += 1
    print(f"✅ 转换完成：{count} 条 → {out_dir}")


if __name__ == "__main__":
    main()
