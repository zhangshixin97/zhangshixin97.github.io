---
name: wechat-typography
version: 1.0
description: 基于「功能全集：排版组件指南」组件库，将文章内容渲染为微信公众号可用的富 HTML 排版，含封面头图、阅读路线、章节标题、图片增强、步骤流、对比卡片、时间线、标签徽章、CTA 等全套组件。
---

# 微信公众号排版技能 1.0

## 核心定位

为公众号文章提供一套完整的富 HTML 排版组件库。当用户需要排版公众号文章时，根据文章内容和结构，从组件库中选择合适的组件组装成最终 HTML。所有组件均为行内样式，支持公众号编辑器直接粘贴。

**适用**：公众号长文排版、教程/指南类文章、产品发布文、案例展示文、年度总结等需要层次分明、视觉丰富的场景。

**不适用**：纯文本短文（800 字以内无需复杂排版）、非公众号平台的排版。

---

## 触发场景

- 用户说"帮我排版一篇公众号文章"
- 用户提供文章草稿，说"按公众号标准排一下"
- 用户说"用排版组件库给这篇文章美化一下"
- 用户在写完文章后说"按组件指南渲染"

---

## 工作流

### Step 1：分析文章结构

通读用户提供的文章内容，识别以下结构要素：

- **标题 + 副标题 + 标签** → 适合封面头部组件
- **多章节分段**（3 个以上章节）→ 适合阅读路线 + 章节标题
- **1-3 张配图** → 适合图片窗口/并排/轮播
- **关键概念/重点句** → 适合行内修饰（渐变背景、胶囊）
- **操作步骤/教程**（2-5 步）→ 适合横向或竖向步骤流
- **案例展示**（多个并列案例）→ 适合案例流
- **新旧对比** → 适合 Before/After 对比卡片
- **时间线/里程碑** → 适合 Timeline 组件
- **重要更新/核心结论** → 适合 Breaking 卡片
- **代码/技术内容** → 适合代码块
- **技术栈/标签** → 适合 Badges 徽章
- **结尾行动号召** → 适合 CTA + 结尾互动组件

如果文章结构不清晰，先帮用户梳理大纲再排版。

### Step 2：选择组件组合

根据文章类型，推荐组件组合：

- **教程/指南类**：封面头部 + 阅读路线 + 章节标题 + 步骤流 + Callout 提示 + 代码块 + CTA
- **产品发布类**：封面头部 + Breaking 卡片 + Before/After 对比 + Badges + CTA
- **案例展示类**：封面头部 + 案例流 + Statement 居中强调 + 结尾互动
- **年终总结类**：封面头部 + 阅读路线 + Timeline + Statement + 结尾互动

输出组件选择方案（列出将使用哪些组件以及放在什么位置），等用户确认后再生成 HTML。

### Step 3：生成 HTML

按文章顺序逐段生成对应的组件 HTML，组件模板见下方「组件库参考」。所有样式均为行内 style，不得使用 class 或外部 CSS。生成规则：

- 颜色主题色为 `#27ae60`（绿色），可根据文章主题调整
- 正文字号 14-16px，颜色 `#333` 或 `#374151`
- 标题字号 18-30px，颜色 `#111827`
- 辅助文字字号 10-13px，颜色 `#94a3b8` 或 `#999`
- 留白间距：章节之间 48px+，组件之间 24-36px，段落之间 16-20px

### Step 4：自检

生成后检查：
- 所有标签正确闭合
- 行内 style 无缺失
- 图片 src 有效（若为占位则标注）
- 移动端预览友好（字号不小于 12px，图片宽度 100%）
- 无 Class 依赖，无外部 CSS 引用

---

## 输出格式

直接输出完整的 HTML 片段（<section> 起步），可直接粘贴到公众号编辑器。若文章较长，分段输出并在每段标注位置。

输出时附上：
```
## 组件使用清单
- 封面头部 ×1
- 阅读路线 ×1
- Chapter 标题 ×3
- 图片窗口 ×2
- 行内渐变强调 ×5
- Callout 提示 ×2
- CTA ×1
- 结尾互动 ×1

可直接复制到公众号编辑器使用。
```

---

## 组件库参考

### 封面头部 (Article Header)

```html
<section style="margin:0px 0px 30px;box-shadow:rgba(15,23,42,0.05) 0px 10px 24px;border-radius:14px;border:1px solid rgba(229,231,235,0.9);overflow:hidden;background:linear-gradient(135deg,rgb(248,250,252) 0%,rgb(238,244,251) 100%)">
  <section style="padding:20px;background:rgba(255,255,255,0.92)">
    <section style="margin:0px 0px 10px;white-space:nowrap">
      <span style="margin:0px;padding:0px;font-size:10px;color:#27ae60;letter-spacing:2.4px;text-transform:uppercase;font-weight:800;white-space:nowrap">GUIDE</span>
      <span style="margin:0px 0px 0px 12px;display:inline-block;font-size:10px;color:rgb(148,163,184);font-weight:700;letter-spacing:0.3px;line-height:1;white-space:nowrap">预计阅读 <span style="font-size:12px;font-weight:900;color:#27ae60">N</span> 分钟 · 共 XXXX 字</span>
    </section>
    <p style="margin:0px;font-size:28px;font-weight:900;color:rgb(17,24,39);line-height:1.2;letter-spacing:-0.5px;word-break:break-all">文章标题</p>
    <p style="margin:0px;padding:10px 0px 0px;font-size:14px;color:rgb(71,85,105);line-height:1.7;font-weight:400">副标题或简介描述</p>
    <section style="margin:0px;padding:10px 0px 0px;font-size:0px;line-height:1.8">
      <span style="display:inline-block;margin:0px 8px 0px 0px;font-size:10px;color:#576B95;font-weight:700;letter-spacing:0.02em;white-space:nowrap">#标签1</span>
      <span style="display:inline-block;margin:0px 8px 0px 0px;font-size:10px;color:#576B95;font-weight:700;letter-spacing:0.02em;white-space:nowrap">#标签2</span>
    </section>
  </section>
</section>
```

可选：用 BADGE 替换 GUIDE；颜色可替换 `#27ae60`。

### 阅读路线 (Reading Path / TOC)

适用于 3+ 章节的长文，横向可滚动。

```html
<section style="margin:0px 0px 30px">
  <section>
    <section style="display:flex;align-items:flex-end;justify-content:space-between;padding-bottom:14px;gap:12px">
      <section style="flex-shrink:0">
        <p style="margin:0px;padding:0px 0px 6px;font-size:10px;color:rgb(100,116,139);text-transform:uppercase;letter-spacing:2.8px;font-weight:800;white-space:nowrap">READING PATH</p>
        <p style="margin:0px;font-size:16px;line-height:1.35;color:rgb(17,24,39);font-weight:800">阅读路线</p>
      </section>
      <p style="margin:0px;font-size:10px;color:rgb(148,163,184);white-space:nowrap">N 个章节</p>
    </section>
    <section style="padding:14px 12px 12px;border:1px solid rgb(229,231,235);border-radius:13px;background:linear-gradient(rgb(255,255,255) 0%,rgb(248,250,252) 100%);box-shadow:rgba(15,23,42,0.04) 0px 12px 30px;overflow-x:auto;white-space:nowrap;font-size:0px">
      <!-- 逐项重复，第一项高亮，其余默认 -->
      <section style="display:inline-flex;vertical-align:middle;align-items:center">
        <section style="display:inline-block;vertical-align:top;width:126px;white-space:normal;text-align:center">
          <section style="display:flex;justify-content:center;margin-bottom:10px">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:999px;background:#27ae60;color:rgb(255,255,255);border:1px solid #27ae60;font-size:11px;font-weight:900;letter-spacing:1.2px;white-space:nowrap">01</span>
          </section>
          <p style="margin:0px;font-size:13px;line-height:1.55;color:rgb(17,24,39);font-weight:800;letter-spacing:0.05px;white-space:normal;word-break:break-all">章节名称</p>
        </section>
        <span style="display:inline-block;vertical-align:middle;width:32px;height:1px;line-height:1px;margin:0px 8px;background:linear-gradient(90deg,rgba(148,163,184,0.35),rgba(148,163,184,0.85));color:transparent;overflow:hidden">-</span>
      </section>
      <!-- 非高亮项：圆背景改为 #fff，文字色改为 #1f2937，边框改为 #dbe3ee -->
    </section>
  </section>
</section>
```

### Chapter 标题

每章开头的大标题，带水印数字。

```html
<section style="margin:48px 0px 30px">
  <section style="clear:both">
    <section style="display:flex;align-items:center;margin:0;padding-bottom:12px">
      <span style="font-size:10px;font-weight:800;color:rgb(148,163,184);letter-spacing:2.6px;text-transform:uppercase;white-space:nowrap">CHAPTER 01</span>
      <section style="flex:1;border-top:1px solid rgb(229,231,235);margin:0 0 0 12px;height:0"></section>
    </section>
    <section style="margin:0">
      <strong style="display:block;font-size:60px;line-height:1;color:#27ae60;letter-spacing:-3px;white-space:nowrap;opacity:0.25">01</strong>
      <strong style="display:block;font-size:30px;font-weight:900;color:rgb(17,24,39);line-height:1.26;letter-spacing:-0.8px;margin-top:-60px;margin-left:50px">章节标题</strong>
      <span style="display:block;margin-left:50px;font-size:11px;color:#27ae60;font-weight:700;text-transform:uppercase;letter-spacing:1.6px">SUB TITLE · 副标题</span>
    </section>
  </section>
</section>
```

### 二级标题（带编号浮左）

```html
<section style="margin:36px 0px 20px;overflow:hidden">
  <section style="float:left;white-space:nowrap;font-size:24px;font-weight:900;color:#27ae60;line-height:1.4;letter-spacing:-0.3px">01</section>
  <section style="margin-left:32px;font-size:24px;font-weight:800;color:rgb(17,24,39);line-height:1.4;letter-spacing:-0.3px">标题文字</section>
</section>
```

三级标题：编号 20px，标题 20px font-weight:700；四级标题：编号 16px，标题 16px font-weight:700。

### 图片窗口滚动（限高 250px）

```html
<section style="max-height:250px;overflow-y:auto;border-radius:8px;margin:12px 0px">
  <img src="图片URL" alt="描述" style="width:100%;display:block">
</section>
```

### 多图横向滑动

```html
<section style="white-space:nowrap;overflow-x:auto;margin:12px 0px;padding:4px 0px">
  <img src="图1URL" alt="图1" style="display:inline-block;vertical-align:top;max-height:200px;border-radius:8px;margin-right:8px">
  <img src="图2URL" alt="图2" style="display:inline-block;vertical-align:top;max-height:200px;border-radius:8px;margin-right:8px">
</section>
```

### 轮播图（SVG，最多 5 张，默认间隔 3s）

使用 SVG animateTransform，viewBox 宽度 × 图片数。每张图片用 foreignObject 包裹。详见用户原始演示稿中的 SVG 轮播代码。宽高可调整，默认 600×200。

### Callout 提示框

```html
<section style="margin:14px 0px;padding:12px 16px;background:rgb(247,248,252);border-left:3px solid #27ae60;border-radius:0px 6px 6px 0px;color:rgb(85,85,85);font-size:14px">
  <section>
    <p style="margin:4px 0px">提示或说明文字</p>
  </section>
</section>
```

带标题版本：

```html
<section style="margin:16px 0px;padding:16px 18px;background:#f0f4fa;border-left:4px solid #27ae60;border-radius:0px 10px 10px 0px">
  <p style="margin:0px 0px 6px;font-size:14px;font-weight:700;color:rgb(51,65,85)">💡 小标题</p>
  <section style="font-size:14px;color:rgb(85,85,85);line-height:1.7">正文内容</section>
</section>
```

### Breaking / 重大更新卡片

```html
<section style="margin:24px 0px;padding:28px 24px;background:radial-gradient(circle 60px at 92% 30px,#27ae6026 96%,transparent 100%),linear-gradient(135deg,#27ae6026,rgba(255,255,255,0.8));border:1px solid #27ae6033;border-radius:16px">
  <span style="display:inline-block;padding:4px 12px;background:#27ae60;color:rgb(255,255,255);border-radius:6px;font-size:11px;font-weight:700;letter-spacing:1px;margin-bottom:12px">NEW</span>
  <p style="margin:0px 0px 8px;font-size:22px;font-weight:800;color:rgb(26,26,26);line-height:1.4">大标题</p>
  <p style="margin:0px 0px 12px;font-size:14px;color:rgb(102,102,102)">副标题描述</p>
  <section style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
    <span style="display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;background:rgba(255,255,255,0.8);color:#27ae60;border:1px solid #27ae6033">#标签</span>
  </section>
  <section style="font-size:14px;color:rgb(85,85,85);line-height:1.8;margin-top:8px">详细描述</section>
</section>
```

### 横向步骤流 (Horizontal Steps)

使用 table 实现三列等宽步骤：

```html
<section style="margin:0px 0px 24px;padding:20px;background:rgb(250,251,254);border-radius:12px;border:1px solid rgb(238,238,238)">
  <p style="margin:0px 0px 4px;font-size:10px;color:rgb(153,153,153);letter-spacing:2px;font-weight:700">HOW IT WORKS</p>
  <p style="margin:0px 0px 4px;font-size:18px;font-weight:800;color:rgb(26,26,26)">标题</p>
  <p style="margin:0px 0px 16px;font-size:12px;color:rgb(153,153,153)">左右滑动查看</p>
  <table border="0" cellpadding="0" cellspacing="12" style="margin:0;border-collapse:separate;border-spacing:12px 0;border:none;width:100%">
    <tbody><tr>
      <td style="vertical-align:top;padding:16px 12px;background:rgb(255,255,255);border-radius:10px;border:1px solid rgb(238,238,238);text-align:center;width:33%">
        <p style="margin:0px 0px 4px;font-size:20px;font-weight:900;color:#27ae60">1</p>
        <p style="margin:0px 0px 2px;font-size:13px;font-weight:700;color:rgb(51,65,85)">步骤名</p>
        <p style="margin:0px;font-size:11px;color:rgb(153,153,153)">步骤描述</p>
      </td>
      <!-- 高亮当前步骤：背景 rgba(39,174,96,0.06)，边框 2px solid #27ae60 -->
      <!-- 重复 td，最多 3-4 列 -->
    </tr></tbody>
  </table>
</section>
```

### 竖向步骤流 (Vertical Steps)

```html
<section style="margin:0px 0px 24px;padding:20px;background:rgb(250,251,254);border-radius:12px;border:1px solid rgb(238,238,238)">
  <p style="margin:0px 0px 4px;font-size:10px;color:rgb(153,153,153);letter-spacing:2px;font-weight:700">VERTICAL STEPS</p>
  <p style="margin:0px 0px 4px;font-size:18px;font-weight:800;color:rgb(26,26,26)">标题</p>
  <!-- 每步重复 -->
  <section style="margin-bottom:12px;padding:16px;background:rgb(255,255,255);border-radius:10px;border:1px solid rgb(238,238,238)">
    <section style="display:inline-block;vertical-align:top;width:32px;margin-right:12px">
      <section style="width:32px;height:32px;border-radius:50%;background:rgb(238,238,238);text-align:center;line-height:32px">
        <span style="font-size:14px;font-weight:900;color:rgb(153,153,153)">1</span>
      </section>
    </section>
    <section style="display:inline-block;vertical-align:top;padding-top:4px">
      <p style="margin:0px 0px 2px;font-size:14px;font-weight:700;color:rgb(51,65,85)">步骤名</p>
      <p style="margin:0px;font-size:12px;color:rgb(153,153,153)">步骤描述</p>
    </section>
  </section>
  <!-- 高亮当前步骤：背景 rgba(39,174,96,0.06)，边框 2px solid #27ae60，圆背景 #27ae60 白字 -->
</section>
```

### 案例流 (Case Flow)

```html
<section style="margin:20px 0;">
  <section style="display:flex;align-items:center;gap:16px;padding:20px;margin-bottom:12px;border:1px solid rgba(0,0,0,0.06);border-radius:12px;background:#fff;">
    <span style="flex-shrink:0;white-space:nowrap;background:rgba(39,174,96,0.12);color:#27ae60;font-size:13px;font-weight:600;padding:6px 14px;border-radius:8px;letter-spacing:0.5px;">案例 01</span>
    <span style="flex:1;font-size:15px;line-height:1.6;color:#333;">案例描述文字</span>
  </section>
  <!-- 重复 -->
</section>
```

### Before / After 对比（横向）

```html
<section style="display:flex;gap:16px;margin:20px 0px">
  <section style="flex:1;min-width:0;padding:16px;background:rgb(250,251,254);border-radius:12px">
    <p style="margin:0px 0px 4px;font-size:10px;font-weight:700;color:rgb(153,153,153);letter-spacing:2px">BEFORE</p>
    <p style="margin:0px 0px 8px;font-size:14px;font-weight:700;color:rgb(51,65,85)">旧版标题</p>
    <img src="旧图URL" alt="旧版" style="width:100%;max-height:120px;border-radius:6px;display:block;margin:6px 0">
  </section>
  <section style="flex:1;min-width:0;padding:16px;background:rgb(250,251,254);border-radius:12px">
    <p style="margin:0px 0px 4px;font-size:10px;font-weight:700;color:#27ae60;letter-spacing:2px">AFTER</p>
    <p style="margin:0px 0px 8px;font-size:14px;font-weight:700;color:rgb(51,65,85)">新版标题</p>
    <img src="新图URL" alt="新版" style="width:100%;max-height:120px;border-radius:6px;display:block;margin:6px 0">
  </section>
</section>
```

### Before / After 对比（纵向）

横向改为 `flex-direction:column;gap:12px`，每段占满宽。

### CTA 行动点召唤

```html
<section style="margin:24px 0px;padding:32px 24px;background:linear-gradient(135deg,#27ae60,#1e8449);border-radius:16px;text-align:center;color:rgb(255,255,255)">
  <p style="margin:0px 0px 8px;font-size:11px;letter-spacing:3px;font-weight:700;opacity:0.8">GET STARTED</p>
  <p style="margin:0px 0px 16px;font-size:20px;font-weight:800;line-height:1.4">准备好开始了吗？</p>
  <span style="display:inline-block;padding:12px 32px;background:rgba(255,255,255,0.2);border-radius:8px;font-weight:700;letter-spacing:1px;backdrop-filter:blur(4px)">行动按钮文字</span>
</section>
```

### 时间线 (Timeline)

```html
<section style="margin:24px 0;padding:24px;background:linear-gradient(135deg, rgba(255,255,255,0.8), rgba(248,250,252,0.6));border:1px solid rgba(0,0,0,0.06);border-radius:16px;">
  <!-- 每项重复，最后一项 border-left 用 transparent -->
  <section style="margin-bottom:32px;overflow:hidden;">
    <section style="float:left;width:12px;height:12px;border-radius:50%;background:#27ae60;box-shadow:0 0 0 4px rgba(39,174,96,0.15);margin:5px 0 0 4px;"></section>
    <section style="margin-left:9px;border-left:2px solid rgba(39,174,96,0.3);padding-left:18px;">
      <p style="margin:0 0 6px;font-size:13px;font-weight:700;color:#27ae60;letter-spacing:0.5px;">时间标签</p>
      <p style="margin:0 0 6px;font-size:17px;font-weight:800;color:rgb(17,24,39);line-height:1.4;">事件标题</p>
      <p style="margin:0;font-size:14px;color:rgb(100,116,139);line-height:1.6;">事件描述</p>
      <!-- 可选图片 -->
    </section>
  </section>
  <!-- 最后一项 border-left:2px solid transparent -->
</section>
```

### 行内修饰

```html
<!-- 渐变背景 -->
<span style="background:linear-gradient(120deg,rgba(39,174,96,0.1) 0%,rgba(39,174,96,0.16) 100%);padding:0px 6px;border-radius:4px;font-weight:700;color:#27ae60">渐变背景文字</span>

<!-- 胶囊文字 -->
<span style="display:inline-block;padding:0 5px;border-radius:20px;font-size:14px;font-weight:600;background:#27ae6026;color:#27ae60;border:1px solid #27ae6033">胶囊标签</span>

<!-- 靛青强调 -->
<strong style="color:#27ae60">强调文字</strong>

<!-- 柔光重点 -->
<span style="color:#47ba78;font-weight:700">柔光重点文字</span>

<!-- 下划线（主题色） -->
<span style="text-decoration:underline;text-decoration-color:#27ae60;text-underline-offset:3px">下划线文字</span>

<!-- 删除线 -->
<del style="color:#9ca3af">删除线文字</del>
```

### 彩色标签徽章 (Badges)

四种预设风格 + 自定义：

```html
<!-- accent（主题色绿） -->
<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:600;background:#27ae6018;color:#27ae60;border:1px solid #27ae6050;line-height:1.6;white-space:nowrap">标签</span>

<!-- green（绿色） -->
<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:600;background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;line-height:1.6;white-space:nowrap">标签</span>

<!-- yellow（黄色） -->
<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:600;background:#fff9c4;color:#f57f17;border:1px solid #fff176;line-height:1.6;white-space:nowrap">标签</span>

<!-- dark（深色） -->
<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:600;background:#263238;color:#eceff1;border:1px solid #455a64;line-height:1.6;white-space:nowrap">标签</span>

<!-- 自定义颜色（红底白字示例） -->
<span style="display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:999px;font-size:13px;font-weight:600;background:#e74c3c;color:#fff;border:1px solid #e74c3c50;line-height:1.6;white-space:nowrap">标签</span>
```

### 代码块

```html
<section style="background:rgb(30,30,46);color:rgb(205,214,244);padding:14px 16px;border-radius:8px;overflow-x:auto;margin:14px 0px;font-size:12.5px;line-height:1.6">
  <code style="background:none;color:inherit;padding:0;font-size:inherit;white-space:pre">代码内容</code>
</section>
```

### Statement 居中强调

```html
<section style="margin:20px 0px">
  <p style="text-align:center;font-size:18px;font-weight:700;color:rgb(51,65,85);line-height:1.6">核心观点或金句</p>
</section>
```

### Lead 引导文字段

```html
<section>
  <p style="font-size:16px;color:rgb(85,85,85);line-height:1.8;padding:16px;border-left:3px solid #27ae60;margin:14px 0px;overflow-wrap:break-word;word-break:break-word">引导文字内容</p>
</section>
```

### 结尾互动（三列：点赞/转发/推荐）

```html
<section style="margin:24px 0;padding:0;position:relative;">
  <section style="background:linear-gradient(135deg,rgba(232,99,111,0.05) 0%,rgba(95,165,90,0.05) 50%,rgba(243,200,133,0.05) 100%);border-radius:16px;padding:24px 16px 20px;position:relative;overflow:hidden;border:1px dashed rgba(229,231,235,0.9);">
    <section style="text-align:center;margin-bottom:20px;">
      <section style="font-size:18px;font-weight:700;color:#333;letter-spacing:1px;line-height:1.5;">感谢你的阅读与支持！</section>
      <section style="font-size:13px;color:#888;margin-top:4px;">喜欢就互动一下吧～ ♥️</section>
    </section>
    <section style="display:flex;justify-content:center;align-items:flex-start;gap:0;">
      <!-- 点赞列 -->
      <section style="flex:1;text-align:center;padding:0 6px;">
        <section style="width:48px;height:48px;border-radius:50%;background:#fff;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(232,99,111,0.15);">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="#e8636f" xmlns="http://www.w3.org/2000/svg"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"></path></svg>
        </section>
        <section style="font-size:15px;font-weight:700;color:#e8636f;margin-bottom:3px;letter-spacing:2px;">· 点赞 ·</section>
        <section style="font-size:11px;color:#999;margin-bottom:6px;">喜欢就点个赞吧</section>
        <section style="width:24px;height:2px;border-radius:2px;background:#e8636f;margin:0 auto;opacity:0.5;"></section>
      </section>
      <!-- 转发列（中间带虚线边框分隔） -->
      <section style="flex:1;text-align:center;padding:0 6px;border-left:1px dashed #e0e0e0;border-right:1px dashed #e0e0e0;">
        <section style="width:48px;height:48px;border-radius:50%;background:#fff;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(95,165,90,0.15);">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="#5fa55a" xmlns="http://www.w3.org/2000/svg"><path d="M21 12l-7-7v4C7 10 4 15 3 20c2.5-3.5 6-5.1 11-5.1V19l7-7z"></path></svg>
        </section>
        <section style="font-size:15px;font-weight:700;color:#5fa55a;margin-bottom:3px;letter-spacing:2px;">· 转发 ·</section>
        <section style="font-size:11px;color:#999;margin-bottom:6px;">分享给更多朋友</section>
        <section style="width:24px;height:2px;border-radius:2px;background:#5fa55a;margin:0 auto;opacity:0.5;"></section>
      </section>
      <!-- 推荐列 -->
      <section style="flex:1;text-align:center;padding:0 6px;">
        <section style="width:48px;height:48px;border-radius:50%;background:#fff;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(243,200,133,0.15);">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="#f3c885" xmlns="http://www.w3.org/2000/svg"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
        </section>
        <section style="font-size:15px;font-weight:700;color:#f3c885;margin-bottom:3px;letter-spacing:2px;">· 推荐 ·</section>
        <section style="font-size:11px;color:#999;margin-bottom:6px;">推荐给身边的人</section>
        <section style="width:24px;height:2px;border-radius:2px;background:#f3c885;margin:0 auto;opacity:0.5;"></section>
      </section>
    </section>
  </section>
</section>
```

---

## Gotchas

1. **公众号编辑器不支持 class / 外部 CSS / script / 表单元素**
   所有样式必须写在行内 style 属性中。不要使用 `<style>` 标签或外部样式表。flex 和 grid 布局基本支持，但 `gap` 在某些安卓端编辑器可能不生效，用 margin 做 fallback。

2. **图片必须使用 https 外链**
   公众号编辑器不支持 base64 图片和本地文件。生成 HTML 时图片 src 使用 `https://` 开头的可访问链接，或标注 `[待替换图片]` 占位。严禁使用 `file://` 路径。

3. **SVG 轮播图在部分安卓手机微信中不播放**
   animateTransform 动画依赖浏览器 SVG 支持，少数旧安卓微信 WebView 中动画不生效。重要图片建议同时提供静态预览图作为 fallback。

4. **横向滚动组件（阅读路线、多图并排）需在 iOS 微信中测试**
   `overflow-x:auto` 在 iOS 微信中有特殊滚动行为。建议在 white-space:nowrap 容器内留上下 padding 避免滚动条遮挡内容。

5. **颜色主题一致性**
   默认主题色为 `#27ae60`（绿色），所有组件的 accent 颜色、边框、背景渐变都已预设该色。如需更换主题色，必须全文统一替换，不可混用。

6. **表格组件宽度限制**
   横向步骤流使用 `<table>` 实现，在小屏手机（宽度 < 375px）上可能出现横向滚动条或文字挤压。建议步骤数不超过 4 列，步骤描述不超过 10 字。

7. **段落间距一致性**
   组件之间间距遵循：章节分隔 48px+、组件间隔 24-36px、段落间隔 16-20px。不要随意调整间距导致视觉层次混乱。

8. **emoji 和特殊字符**
   组件中使用的 emoji（如 💡）在不同系统中渲染效果不同。建议保留组件模板中的 emoji，不要替换为图片。如需添加自定义 emoji，控制在全文 5-8 个以内。
