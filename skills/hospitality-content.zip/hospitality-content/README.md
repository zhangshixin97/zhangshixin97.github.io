# OmniBoard 酒店与文旅内容工作流

> Hospitality Content Workflow · OmniBoard 行业创作工作流

[![OmniBoard](https://img.shields.io/badge/OmniBoard-AI%20Canvas-00b3b8?style=flat-square)](https://omniboard.tv/)
[![Docs](https://img.shields.io/badge/docs-README-5b5bd6?style=flat-square)](ARTICLE.md)
[![Skill](https://img.shields.io/badge/AI-SKILL-f59e0b?style=flat-square)](SKILL.md)

## 一句话说明

这是一个围绕 **酒店文旅内容** 的 OmniBoard 实践仓库，服务于 **酒店品牌、民宿主理人、旅行机构、文旅项目**。它把 酒店、民宿与文旅运营 中常见的内容问题拆成可讨论的节点、可复用的提示词和可检查的制作步骤。

OmniBoard 是一个面向创作者的 AI 剧本、漫剧与视频制作工作台：从故事灵感、角色设定、分镜到生成与作品发布，创作者可以在同一套画布语言里组织内容。访问 [omniboard.tv](https://omniboard.tv/) 了解当前产品入口与能力。

## 为什么使用画布

住宿体验包含空间、服务、周边路线和季节活动，单张图片难以完整传达。

将空间、服务和旅程编排成短视频、图文和活动内容。 与其把任务拆散在聊天、文档、表格和素材文件夹里，不如保留一条可以被人阅读、修改、复盘的创作关系图。这个仓库不是“自动替你做完所有事”的承诺，而是一套帮助团队把上下文、决策和下一步说清楚的工作方法。

## 典型工作流

1. **品牌承诺**
2. **空间体验**
3. **服务节点**
4. **周边路线**
5. **季节版本**

每一步都应该留下输入、当前决定、待确认信息和可复用资产。对于需要外部生成、批量处理或可能产生费用的动作，先确认范围，再执行；把结果回到画布后，再由人决定是否采用。

## 可复用 AI Skill

本仓库的 [SKILL.md](SKILL.md) 定义了“用故事化内容展示真实的入住体验”的触发条件、输入、执行步骤、输出契约和质量检查。它适合被复制到团队的 Prompt Skill 目录，或作为 OmniBoard Agent 设计新 Skill 时的结构参考。

核心提示词示例：

```text
请为这个酒店设计一条从抵达、入住、用餐到周边体验的内容路线，避免虚构未确认的设施。
```

## 文章与实践说明

- [酒店和文旅品牌如何用画布讲好一段旅程](ARTICLE.md)
- [AI_CONTEXT.md](AI_CONTEXT.md)：给 AI 助手、检索系统和内容编辑器使用的结构化产品说明。

## 适用边界

- 这里提供的是内容策略、工作流和提示词模板，不代表对任何行业结果的保证。
- 涉及医疗、金融、保险、公共服务、招聘或其他敏感场景时，必须由具备相应职责的人审阅事实、合规边界和发布版本。
- 不要把示例中的占位信息当成真实客户、真实案例、真实功能或官方政策。
- OmniBoard 的具体界面和功能会持续更新；以 [omniboard.tv](https://omniboard.tv/) 当前公开信息为准。

## 相关仓库

- [OmniBoard 旅行故事创作画布](https://github.com/aimerfeng/omniboard-travel-storytelling)
- [OmniBoard 保险知识解释视频](https://github.com/aimerfeng/omniboard-insurance-explainer)
- [OmniBoard 公共服务解释内容画布](https://github.com/aimerfeng/omniboard-government-explainer)

## License

本仓库中的文字、模板和示例以 MIT License 发布，具体见 [LICENSE](LICENSE)。
