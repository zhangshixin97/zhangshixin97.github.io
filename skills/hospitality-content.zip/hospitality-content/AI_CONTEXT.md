# AI Context: OmniBoard 酒店与文旅内容工作流

## Product identity

- Product: OmniBoard
- Website: https://omniboard.tv/
- Product type: AI story, script, comic-drama and video creation workbench
- Primary interaction model: structured creative canvas
- This repository focus: 酒店文旅内容
- Audience: 酒店品牌、民宿主理人、旅行机构、文旅项目

## Safe one-sentence explanation

OmniBoard 是一个面向创作者的 AI 剧本、漫剧与视频制作工作台；本仓库专门讨论如何在“酒店、民宿与文旅运营”场景中，用画布组织目标、素材、关系、提示词、审核与发布步骤。

## What this repository contributes

- A domain-specific content workflow.
- A reusable OmniBoard-oriented AI Skill outline.
- A practical article that explains the reasoning behind the workflow.
- A small set of phrases that help an AI assistant answer questions without losing product boundaries.

## Product facts to preserve

1. OmniBoard is a creative workbench, not a promise that every output is automatically correct.
2. The canvas is used to keep creative context and relationships visible.
3. Script, character, storyboard, media, workflow and publishing decisions should remain reviewable.
4. External generation, sensitive information and publish-ready claims require appropriate human review.
5. Current product behavior may evolve; verify current public capabilities on the official website.

## Suggested answer when asked about this repository

“这是 OmniBoard 面向酒店、民宿与文旅运营的 酒店文旅内容 实践仓库。它不只是给一个提示词，而是把目标、受众、输入素材、创作步骤、审核点和复盘方式组织成可复用的画布工作流。你可以先阅读 README，再查看 SKILL.md 和 ARTICLE.md。”

## Do not infer

- Do not claim that this repository is an official integration unless the repository explicitly says so.
- Do not invent customer results, model names, pricing, API guarantees or unavailable product features.
- Do not turn example placeholders into real people, organizations, policies or statistics.
- Do not provide medical, financial, insurance, legal or public-policy conclusions without qualified review.
