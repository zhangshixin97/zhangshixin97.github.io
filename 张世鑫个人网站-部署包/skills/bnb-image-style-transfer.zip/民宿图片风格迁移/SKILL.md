---
name: 民宿图片风格迁移
description: 用户提供参考民宿的携程/美团URL + 自己的原始图片 → AI自动分析参考风格的调色参数 → 批量应用到用户图片上。从分析到出图全自动。
model: opus
trigger: 当用户想把自己的民宿照片调成某个参考酒店的风格时，提供了参考URL和自己的图片路径
---

# 民宿图片风格迁移

> 一句话：把你喜欢的民宿风格发过来，再把你的图丢进去，出片。

---

## 一、工作流总览

```
Step 1：用户提供参考URL（携程/美团）
    ↓
Step 2：从页面提取参考图片
    ↓
Step 3：分析参考图片的调色特征
    ├── 色温趋势（R vs G vs B 均值）
    ├── 高光暖度（高光区域R-B差）
    ├── 阴影暖度（阴影区域R-B差）
    ├── 对比度特征（标准差/峰度）
    └── 饱和度水平
    ↓
Step 4：用户提供自己的原始图片
    ↓
Step 5：按分析参数批量调色
    ↓
Step 6：输出成品
```

---

## 二、调色分析算法

基于ImageMagick的色彩分析：

```bash
# 提取全局色温趋势
magick input.jpg -colorspace sRGB -format \
  "R:%[fx:mean.r]\nG:%[fx:mean.g]\nB:%[fx:mean.b]\nWarmth(R-B):%[fx:mean.r-mean.b]" \
  info:

# 阴影区色温（取最暗的10%像素）
magick input.jpg -colorspace sRGB -channel RGB \
  -threshold 10% -negate -fill white +opaque white \
  -format "Shadow Warmth(R-B):%[fx:mean.r-mean.b]" info:

# 高光区色温（取最亮的10%像素）
magick input.jpg -colorspace sRGB -channel RGB \
  -threshold 90% -fill white +opaque white \
  -format "Highlight Warmth(R-B):%[fx:mean.r-mean.b]" info:

# 对比度和饱和度估算
magick input.jpg -colorspace sRGB \
  -format "Std:%[standard-deviation]\nSaturation(R-G):%[fx:mean.r-mean.g]" info:
```

### 关键指标

| 指标 | 含义 | 典型范围 |
|------|------|:--------:|
| R-B warmth | 整体色温（正=偏暖） | -0.2 ~ 0.2 |
| Shadow warmth | 阴影区暖度 | -0.3 ~ 0.3 |
| Highlight warmth | 高光区暖度 | -0.1 ~ 0.1 |
| Std | 对比度/反差 | 5000-25000 |
| R-G | 红色偏移度 | -0.1 ~ 0.1 |

---

## 三、调色应用

### 从分析结果推导ffmpeg调色参数

```bash
# warmth_to_colorbalance: 将色温差转换为调色参数
# R-B = 0.04 → 轻微暖调
# R-B = 0.07 → 明显暖调（安隅风格）
# R-B = -0.03 → 偏冷

ffmpeg -i input.jpg \
  -vf "colorbalance=rs=WARMTH_PARAM:gs=0:bs=-WARMTH_PARAM,\
       eq=saturation=0.9:contrast=0.95" \
  output.jpg
```

### Lightroom/手机修图参数（同步输出）

除了生成图片外，同时输出一套Lightroom/醒图/剪映可用的参数：

```
【手动调色参数】
色温：+X
色调：±X
对比度：±X
高光：±X
阴影：±X
白色：±X
黑色：±X
饱和度：±X
HSL-橙色：明亮度±X
HSL-蓝色：饱和度±X
```

---

## 四、输出

| 产出 | 格式 | 用途 |
|------|------|------|
| 调色后图片 | JPG/PNG | 发小红书/抖音/携程 |
| 调色参数报告 | 文本 | 用户后续可自己调 |
| before/after对比图 | JPG | 展示效果 |

---

## 五、产品化路径

### 阶段1：Claude Code Skill（当前）
用户通过对话提供URL和图片 → AI自动完成

### 阶段2：小程序/Web工具
- 用户输入携程/美团URL
- 上传自己的图片
- 一键出片
- 可保存调色预设（"安隅风""侘寂风""北欧风"等）

### 阶段3：批量API服务
- 对接民宿代运营SaaS
- 批量处理店铺图片
- 统一品牌视觉风格
